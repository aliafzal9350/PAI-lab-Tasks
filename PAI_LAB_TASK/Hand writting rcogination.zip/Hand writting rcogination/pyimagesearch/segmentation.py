# pyimagesearch/segmentation.py
import cv2
import numpy as np

def segment_characters(image_path):
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    _, thresh = cv2.threshold(image, 128, 255, cv2.THRESH_BINARY_INV)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    characters = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        if w*h > 100:  # Filter out small noise
            roi = thresh[y:y+h, x:x+w]
            roi = cv2.resize(roi, (28, 28))
            characters.append(roi)
    return characters
