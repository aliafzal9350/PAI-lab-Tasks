import cv2
import numpy as np
from tensorflow.keras.models import load_model

def capture_image(output_path='static/captured_image.png'):
    """Captures an image from the webcam and saves it."""
    cap = cv2.VideoCapture(0)
    ret, frame = cap.read()
    if ret:
        cv2.imwrite(output_path, frame)
    cap.release()

def predict_characters(characters, model_path='model/ocr_model.h5'):
    """Predicts characters using a trained CNN model."""
    model = load_model(model_path)
    predictions = ''
    for char in characters:
        char = char.reshape(1, 28, 28, 1) / 255.0
        pred = model.predict(char)
        predictions += str(np.argmax(pred))
    return predictions
